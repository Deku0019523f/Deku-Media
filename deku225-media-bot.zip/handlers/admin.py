# -*- coding: utf-8 -*-
"""
Handler pour le panneau administrateur - VERSION CORRIGÉE FINALE
"""
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, ConversationHandler
from telegram.constants import ParseMode
from utils.database import db
from utils.user_manager import user_manager
from config import ADMIN_IDS, PLATFORMS_ENABLED
from datetime import datetime
import json
import asyncio

# États de conversation
BROADCAST_MESSAGE, BAN_REASON = range(2)

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menu principal admin"""
    user_id = update.effective_user.id
    
    if user_id not in ADMIN_IDS:
        await update.message.reply_text("❌ Accès refusé.")
        return
    
    keyboard = [
        [
            InlineKeyboardButton("👥 Utilisateurs", callback_data="admin_users"),
            InlineKeyboardButton("💳 Paiements", callback_data="admin_payments")
        ],
        [
            InlineKeyboardButton("📊 Statistiques", callback_data="admin_stats"),
            InlineKeyboardButton("🎁 Parrainages", callback_data="admin_referrals")
        ],
        [
            InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast"),
            InlineKeyboardButton("⚙️ Paramètres", callback_data="admin_settings")
        ],
        [
            InlineKeyboardButton("📝 Logs", callback_data="admin_logs")
        ]
    ]
    
    await update.message.reply_text(
        "🛡 **PANNEAU ADMINISTRATEUR**\n\nChoisissez une option :",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def admin_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Retour au menu admin"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    keyboard = [
        [
            InlineKeyboardButton("👥 Utilisateurs", callback_data="admin_users"),
            InlineKeyboardButton("💳 Paiements", callback_data="admin_payments")
        ],
        [
            InlineKeyboardButton("📊 Statistiques", callback_data="admin_stats"),
            InlineKeyboardButton("🎁 Parrainages", callback_data="admin_referrals")
        ],
        [
            InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast"),
            InlineKeyboardButton("⚙️ Paramètres", callback_data="admin_settings")
        ],
        [
            InlineKeyboardButton("📝 Logs", callback_data="admin_logs")
        ]
    ]
    
    await query.edit_message_text(
        "🛡 **PANNEAU ADMINISTRATEUR**\n\nChoisissez une option :",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def admin_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les statistiques globales"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    stats = await db.get_global_stats()
    
    text = f"""📊 **STATISTIQUES GLOBALES**

👥 **Utilisateurs :**
• Total : {stats['total_users']}
• Premium : {stats['premium_users']}
• Ratio : {(stats['premium_users']/stats['total_users']*100) if stats['total_users'] > 0 else 0:.1f}%

📥 **Téléchargements :**
• Aujourd'hui : {stats['today_downloads']}
• Total : {stats['total_downloads']}
• Moyenne/user : {(stats['total_downloads']/stats['total_users']) if stats['total_users'] > 0 else 0:.1f}
"""
    
    keyboard = [[InlineKeyboardButton("🔙 Retour", callback_data="admin_menu")]]
    
    await query.edit_message_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def admin_payments_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les paiements en attente"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    pending = await db.get_pending_payments()
    
    if not pending:
        text = "✅ Aucun paiement en attente."
        keyboard = [[InlineKeyboardButton("🔙 Retour", callback_data="admin_menu")]]
    else:
        text = f"💳 **PAIEMENTS EN ATTENTE** ({len(pending)})\n\n"
        keyboard = []
        
        for payment in pending[:5]:
            user_id = payment['user_id']
            username = payment['username']
            payment_id = payment['id']
            created = payment['created_at']
            
            text += f"• @{username} (ID: `{user_id}`)\n"
            text += f"  Date: {created[:10]}\n\n"
            
            keyboard.append([
                InlineKeyboardButton(
                    f"✅ #{payment_id}",
                    callback_data=f"admin_validate_{payment_id}_{user_id}"
                ),
                InlineKeyboardButton(
                    f"❌ #{payment_id}",
                    callback_data=f"admin_reject_{payment_id}_{user_id}"
                )
            ])
        
        keyboard.append([InlineKeyboardButton("🔙 Retour", callback_data="admin_menu")])
    
    await query.edit_message_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def admin_users_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menu de gestion des utilisateurs"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    keyboard = [
        [InlineKeyboardButton("⭐️ Donner Premium", callback_data="admin_give_premium")],
        [InlineKeyboardButton("🚫 Bannir user", callback_data="admin_ban_user")],
        [InlineKeyboardButton("✅ Débannir user", callback_data="admin_unban_user")],
        [InlineKeyboardButton("🔄 Reset limites", callback_data="admin_reset_limits")],
        [InlineKeyboardButton("🔙 Retour", callback_data="admin_menu")]
    ]
    
    await query.edit_message_text(
        "👥 **GESTION UTILISATEURS**\n\nChoisissez une action :",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def admin_settings_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Paramètres du bot"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    text = "⚙️ **PARAMÈTRES DU BOT**\n\n📺 **Plateformes :**\n\n"
    keyboard = []
    
    for platform, enabled in PLATFORMS_ENABLED.items():
        status = "✅" if enabled else "❌"
        text += f"{status} {platform.capitalize()}\n"
        
        keyboard.append([
            InlineKeyboardButton(
                f"{'❌ Désactiver' if enabled else '✅ Activer'} {platform}",
                callback_data=f"admin_toggle_{platform}"
            )
        ])
    
    keyboard.append([InlineKeyboardButton("🔙 Retour", callback_data="admin_menu")])
    
    await query.edit_message_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def admin_toggle_platform(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Active/Désactive une plateforme"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    platform = query.data.replace("admin_toggle_", "")
    PLATFORMS_ENABLED[platform] = not PLATFORMS_ENABLED.get(platform, True)
    
    status = "✅ activée" if PLATFORMS_ENABLED[platform] else "❌ désactivée"
    await query.answer(f"{platform.capitalize()} {status}")
    
    await admin_settings_callback(update, context)

async def admin_referrals_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les statistiques de parrainage"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    from config import USERS_DIR
    
    total_referrals = 0
    top_referrers = []
    
    for user_file in USERS_DIR.glob("*.json"):
        try:
            with open(user_file, 'r', encoding='utf-8') as f:
                user_data = json.load(f)
            
            invited = len(user_data.get("invited_users", []))
            if invited > 0:
                total_referrals += invited
                top_referrers.append({
                    'id': user_data['id'],
                    'username': user_data.get('username', 'N/A'),
                    'invited': invited,
                    'points': user_data.get('points', 0)
                })
        except:
            pass
    
    top_referrers.sort(key=lambda x: x['invited'], reverse=True)
    
    text = f"🎁 **SYSTÈME DE PARRAINAGE**\n\n"
    text += f"📊 Total parrainages : {total_referrals}\n\n"
    text += "🏆 **Top 5 parrains :**\n\n"
    
    for i, referrer in enumerate(top_referrers[:5], 1):
        text += f"{i}. @{referrer['username']} (ID: `{referrer['id']}`)\n"
        text += f"   • Invités : {referrer['invited']}\n"
        text += f"   • Points : {referrer['points']}\n\n"
    
    keyboard = [[InlineKeyboardButton("🔙 Retour", callback_data="admin_menu")]]
    
    await query.edit_message_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def admin_logs_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les derniers logs"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    from config import LOG_FILE
    
    try:
        with open(LOG_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            last_lines = lines[-20:] if len(lines) > 20 else lines
        
        logs_text = "".join(last_lines[-10:])
        
        text = "📝 **DERNIERS LOGS**\n\n"
        text += f"``````"
        
    except Exception as e:
        text = f"❌ Erreur lecture logs : {e}"
    
    keyboard = [[InlineKeyboardButton("🔙 Retour", callback_data="admin_menu")]]
    
    await query.edit_message_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def admin_broadcast_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Initie le broadcast"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return ConversationHandler.END
    
    await query.edit_message_text(
        "📢 **BROADCAST**\n\n"
        "Envoyez le message à diffuser à tous les utilisateurs.\n\n"
        "Utilisez /cancel pour annuler.",
        parse_mode=ParseMode.MARKDOWN
    )
    
    return BROADCAST_MESSAGE

async def admin_receive_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Reçoit et envoie le broadcast"""
    if update.effective_user.id not in ADMIN_IDS:
        return ConversationHandler.END
    
    message = update.message.text
    
    await update.message.reply_text("📤 Envoi en cours...")
    
    from config import USERS_DIR
    
    success = 0
    failed = 0
    
    for user_file in USERS_DIR.glob("*.json"):
        user_id = int(user_file.stem)
        try:
            await context.bot.send_message(user_id, message, parse_mode=ParseMode.MARKDOWN)
            success += 1
            await asyncio.sleep(0.05)
        except:
            failed += 1
    
    await update.message.reply_text(
        f"✅ **Broadcast terminé !**\n\n"
        f"✅ Envoyés : {success}\n"
        f"❌ Échecs : {failed}",
        parse_mode=ParseMode.MARKDOWN
    )
    
    return ConversationHandler.END

async def admin_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Annule l'opération admin"""
    await update.message.reply_text("❌ Opération annulée.")
    return ConversationHandler.END

async def admin_give_premium_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Demande l'ID pour donner Premium"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    await query.edit_message_text(
        "⭐️ **DONNER PREMIUM**\n\n"
        "Envoyez l'ID de l'utilisateur :\n"
        "`/setpremium USER_ID JOURS`\n\n"
        "Exemple : `/setpremium 123456789 60`",
        parse_mode=ParseMode.MARKDOWN
    )

async def admin_ban_user_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Demande l'ID pour bannir"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    await query.edit_message_text(
        "🚫 **BANNIR UTILISATEUR**\n\n"
        "Envoyez la commande :\n"
        "`/ban USER_ID RAISON`\n\n"
        "Exemple : `/ban 123456789 Spam`",
        parse_mode=ParseMode.MARKDOWN
    )

async def admin_unban_user_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Demande l'ID pour débannir"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    await query.edit_message_text(
        "✅ **DÉBANNIR UTILISATEUR**\n\n"
        "Envoyez la commande :\n"
        "`/unban USER_ID`\n\n"
        "Exemple : `/unban 123456789`",
        parse_mode=ParseMode.MARKDOWN
    )

async def admin_reset_limits_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Reset les limites d'un utilisateur"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        return
    
    await query.edit_message_text(
        "🔄 **RESET LIMITES**\n\n"
        "Envoyez la commande :\n"
        "`/resetlimits USER_ID`\n\n"
        "Exemple : `/resetlimits 123456789`",
        parse_mode=ParseMode.MARKDOWN
    )
